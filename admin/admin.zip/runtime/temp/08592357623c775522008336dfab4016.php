<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"D:\phpstudy\PHPTutorial\WWW\admin\public/../application/index\view\sendcard\send.html";i:1544421716;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>赠送房卡</title>
    <link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
    <script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
    <style>
        *{margin: 0;padding: 0;}
        html,body{width: 100%;height: 100%;}
        body{position: absolute;top: 0;left: 0;background:url('/static/images/bg_sendCards.jpg') 100% 100%;background-size: 100% 100%;}
        .card-content{background:url('/static/images/img_package.png') 100% 100%;background-size: 100% 100%;width: 80%;height: 25rem;margin-top: 40%;margin-left: 10%;text-align: center;overflow: hidden;}
        .yuan{margin-top: 2rem;}
        .yuan img{width: 4rem;height: 4rem;border-radius: 2rem;}
        .nickname{margin-top: 4rem;}
        .card{margin-top: 1rem;}
        .card p{font-size: 1.5rem;font-weight: 700;}
        .btn-receive{margin-top:2rem;}
        .not-got{width: 5rem;height: 5rem;}
        .has-got{width: 5rem;height: 2rem;}
        .gift{text-align: center;}
        .gift a{color: #f5f5f5;}
    </style>
</head>
<body>
    <div class="layui-row">
        <div class="card-content">
            <div class="layui-row yuan">
                <img src="<?php echo $data['sender']['avatar']; ?>" />
            </div>
            <div class="layui-row nickname">
                <p><?php echo $data['sender']['nickname']; ?></p>
            </div>
            <div class="layui-row card">
                <p>送您<?php echo $data['card_num']; ?>张房卡</p>
            </div>
            <div class="layui-row btn-receive">
                <?php echo isset($data['receiver']) && $data['receiver'] != false ? '<img src="/static/images/img_hasGot.png" class="has-got"/><p>领取人:'.$data["receiver"]["nickname"].'</p><p>领取时间:'.date("Y-m-d H:i:s",$data["receive_time"]).'</p>' : '<img src="/static/images/btn_getCards.png" class="not-got" onclick="receive()"/>'; ?>
            </div>
        </div>
    </div>
    <div class="layui-row gift">
        <a href="/index.php/index/Cardgift/index">我的礼包</a>
    </div>
    <script>
        layui.use(['layer'],function(){
			layer = layui.layer;
			$ = layui.jquery;
		});

        function receive(){
            var id = "<?php echo $data['id']; ?>";
            //console.log('id = '+id);
            if(id == undefined || id == null || id == 0){
                layer.msg('礼包不存在',{'icon':2,'anim':6});
                return;
            }
            $.post('/index.php/index/Sendcard/receiveCardAjax',{id:id},function(res){
                console.log(res);
                if(res.code == 0){
                    layer.msg(res.msg,{'icon':2,'anim':6});
                    return;
                }else{
                    setTimeout(function(){
                        window.location.href = "/index.php/index/Cardgift/index";
                    },1000);
                }
            },'json')
        }
    </script>
</body>
</html>