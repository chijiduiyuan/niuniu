<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"D:\phpstudy\PHPTutorial\WWW\admin\public/../application/index\view\personal\index.html";i:1544427657;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>个人中心</title>
    <link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
    <script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
    <style>
        *{margin: 0;padding: 0;}
        html,body{width: 100%;height: 100%;}
        p{color: #f5f5f5;}
        body{position: absolute;top: 0;left: 0;background:url('/static/images/bg.png') 100% 100%;background-size: 100% 100%;}
        .avatar-row{text-align: center;margin-top: 1rem;}
        .avatar{width: 5rem;height: 5rem;border-radius: 2.5rem;}
        .avatar-row p{font-size: 700;margin-top: 0.5rem;}
        .card-row{margin: 0.5rem 0;text-align: center;}
        .icon-card,.icon-phone{width: 1.5rem;height: 2.5rem;}
        .div-bg{background: url('/static/images/gray_bg.png') 100% 100%;background-size: 100% 100%;width: 94%;height: 1.6rem;margin: 0.5rem 3%;}
        .div-bg p{line-height: 1.6rem;}
        .icon{width: 1.5rem;height: 1.2rem;margin: 0.2rem;}
        .icon img{width: 100%;height: 100%;}
        .icon-right{height: 1.2rem;margin: 0.2rem;}
        .icon-right img{width: 100%;height: 100%;}
        .btn-home{width: 3rem;height: 3rem;position: fixed;top: 1rem;right: 1rem;}
        .btn-home img{width: 100%;height: 100%;}
        .margin-null{margin-bottom: 4rem;}
        .btom{background: url('/static/images/tabbar_bottom.png') 100% 100%;background-size: 100% 100%;width: 100%;height: 4rem;position: fixed;left: 0;bottom: 0;}
        .tab{width: 40%;height: 3rem;display: inline-block;margin: 0.5rem 30%;}
        .tab img{width: 3rem;height: 3rem;}
    </style>
</head>
<body>
    <!--个人信息部分-->
    <div class="layui-container">
        <div class="layui-row avatar-row">
            <div class="layui-col-xs4 layui-col-xs-offset4">
                <img src="<?php echo $data['user']['avatar']; ?>" class="avatar"/>
                <p>UID:<?php echo $data['user']['uid']; ?></p>
                <p><?php echo $data['user']['nickname']; ?></p>
            </div>
        </div>
        <div class="layui-row card-row">
            <div class="layui-col-xs6">
                <div class="layui-col-xs6 layui-col-xs-offset2">
                    <img src="/static/images/icon_card.png" class="icon-card"/>
                    <p><?php echo $data['user']['card']; ?></p>
                </div>
            </div>
            <div class="layui-col-xs6">
                <div class="layui-col-xs6 layui-col-xs-offset2">
                    <img src="/static/images/icon_mobile.png" class="icon-phone"/>
                    <p><?php echo isset($data['user']['phone']) ? $data['user']['phone'] : '未绑定'; ?></p>
                </div>
            </div>
        </div>
    </div>

    <!--赠送房卡-->
    <div class="layui-row div-bg" onclick="sendCard()">
        <div class="layui-col-xs2 icon">
            <img src="/static/images/sendCard.png" />
        </div>
        <div class="layui-col-xs9">
            <P>赠送房卡</P>
        </div>
        <div class="layui-col-xs1 icon-right">
            <img src="/static/images/arrow.png" />
        </div>
    </div>

    <!--房卡记录-->
    <div class="layui-row div-bg" onclick="cardGift()">
        <div class="layui-col-xs2 icon">
            <img src="/static/images/sendCard.png" />
        </div>
        <div class="layui-col-xs9">
            <P>房卡记录</P>
        </div>
        <div class="layui-col-xs1 icon-right">
            <img src="/static/images/arrow.png" />
        </div>
    </div>

    <!--开房查询-->
    <div class="layui-row div-bg" onclick="roomSearch()">
        <div class="layui-col-xs2 icon">
            <img src="/static/images/cardsQuery.png" />
        </div>
        <div class="layui-col-xs9">
            <P>开房查询</P>
        </div>
        <div class="layui-col-xs1 icon-right">
            <img src="/static/images/arrow.png" />
        </div>
    </div>

    <!--游戏记录-->
    <div class="layui-row div-bg">
        <div class="layui-col-xs2 icon">
            <img src="/static/images/gamerecord.png" />
        </div>
        <div class="layui-col-xs9">
            <P>游戏记录</P>
        </div>
        <div class="layui-col-xs1 icon-right">
            <img src="/static/images/arrow.png" />
        </div>
    </div>

    <!--牌友群-->
    <div class="layui-row div-bg">
        <div class="layui-col-xs2 icon">
            <img src="/static/images/friendGroup.png" />
        </div>
        <div class="layui-col-xs9">
            <P>牌友群</P>
        </div>
        <div class="layui-col-xs1 icon-right">
            <img src="/static/images/arrow.png" />
        </div>
    </div>

    <!--成员列表-->
    <div class="layui-row div-bg">
        <div class="layui-col-xs2 icon">
            <img src="/static/images/memberList.png" />
        </div>
        <div class="layui-col-xs9">
            <P>成员列表</P>
        </div>
        <div class="layui-col-xs1 icon-right">
            <img src="/static/images/arrow.png" />
        </div>
    </div>

    <!--邀请函-->
    <div class="layui-row div-bg">
        <div class="layui-col-xs2 icon">
            <img src="/static/images/inviter.png" />
        </div>
        <div class="layui-col-xs9">
            <P>邀请函</P>
        </div>
        <div class="layui-col-xs1 icon-right">
            <img src="/static/images/arrow.png" />
        </div>
    </div>

    <!--密钥设置-->
    <div class="layui-row div-bg">
        <div class="layui-col-xs2 icon">
            <img src="/static/images/setSigb.png" />
        </div>
        <div class="layui-col-xs9">
            <P>密钥设置</P>
        </div>
        <div class="layui-col-xs1 icon-right">
            <img src="/static/images/arrow.png" />
        </div>
    </div>

    <!--通知与反馈-->
    <div class="layui-row div-bg">
        <div class="layui-col-xs2 icon">
            <img src="/static/images/feedbook.png" />
        </div>
        <div class="layui-col-xs9">
            <P>通知与反馈</P>
        </div>
        <div class="layui-col-xs1 icon-right">
            <img src="/static/images/arrow.png" />
        </div>
    </div>

    <!--退出登陆-->
    <div class="layui-row div-bg" onclick="logout()">
        <div class="layui-col-xs2 icon">
            <img src="/static/images/sendCard.png" />
        </div>
        <div class="layui-col-xs9">
            <P>退出登陆</P>
        </div>
        <div class="layui-col-xs1 icon-right">
            <img src="/static/images/arrow.png" />
        </div>
    </div>

    <!--撑开底部-->
    <div class="margin-null"></div>
    <!--大厅导航-->
    <div class="btn-home" onclick="backHome()">
        <img src="/static/images/btn_home.png" />
    </div>
    <!--底部导航-->
    <div class="btom">
        <div class="layui-row">
            <div class="layui-col-xs4">
                <a href="" class="tab"><img src="/static/images/tab_shop_nor.png" /></a>
            </div>
            <div class="layui-col-xs4">
                <a href="" class="tab"><img src="/static/images/tab_club_nor.png" /></a>
            </div>
            <div class="layui-col-xs4">
                <a href="/index.php/index/Personal/index" class="tab"><img src="/static/images/tab_me_nor.png" /></a>
            </div>
        </div>
    </div>

    <script>
        layui.use('layer',function(){
			layer = layui.layer;
			$ = layui.jquery;
		});
        //返回大厅
        function backHome(){
            window.location.href = "/index.php/index/Index/index";
        }

        //赠送房卡
        function sendCard(){
            window.location.href = "/index.php/index/Sendcard/index";
        }

        //房卡礼包
        function cardGift(){
            window.location.href = "/index.php/index/Cardgift/index";
        }

        //开房查询
        function roomSearch(){
            window.location.href = "/index.php/index/Roomsearch/index";
        }


        //退出登陆
        function logout(){
            layer.confirm('确定要退出吗？', {
			  btn: ['确定','取消']
			}, function(){
                $.post('/index.php/index/Personal/logout',{},function(res){
                    //console.log(res);
                    if(res.code == 0){
                        layer.msg(res.msg,{'icon':2,'anim':6});
                        return;
                    }else{
                        layer.msg(res.msg,{'icon':1});
                        setTimeout(function(){
                            window.location.href = "/index.php/index/Login/login";
                        },1000);
                    }
                },'json')
			});
        }
    </script>
</body>
</html>