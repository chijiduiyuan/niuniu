<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"D:\phpstudy\PHPTutorial\WWW\admin\public/../application/index\view\Index\nn.html";i:1543383333;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>创建房间</title>
	<link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
	<script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
	<style>
		.wanfa{height: 4.5rem;}
	</style>
</head>
<body style="padding: 10px;">
	<form class="layui-form">
		<input type="hidden" name="gameId" value="<?php echo $game['id']; ?>">
		<div class="layui-tab layui-tab-brief" lay-filter="docDemoTabBrief">
			<!--玩法-->
			<ul class="layui-tab-title layui-row layui-col-space10">
				<li class="layui-this layui-col-xs3">明牌抢庄</li>
				<li class="layui-col-xs3">牛牛上庄</li>
				<li class="layui-col-xs3">自由抢庄</li>
				<li class="layui-col-xs3">固定庄家</li>
			</ul>
			<div class="layui-tab-content">
				<!--底分-->
				<div class="layui-row">
					<div class="layui-col-xs2">底分:</div>
					<div class="layui-col-xs10">
						<div class="layui-row">
							<input type="radio" name="difen" value="1" title="1分" checked class="layui-col-xs4" lay-filter="difen">
							<input type="radio" name="difen" value="2" title="2分" class="layui-col-xs4" lay-filter="difen">
							<input type="radio" name="difen" value="3" title="3分" class="layui-col-xs4" lay-filter="difen">
							<input type="radio" name="difen" value="4" title="4分" class="layui-col-xs4" lay-filter="difen">
							<input type="radio" name="difen" value="5" title="5分" class="layui-col-xs4" lay-filter="difen">
							<select name="difen" lay-verify="required" lay-filter="difen">
								<option value="0">请选择</option>
								<option value="1">1分</option>
								<option value="2">2分</option>
								<option value="3">3分</option>
								<option value="4">4分</option>
								<option value="5">5分</option>
								<option value="6">6分</option>
								<option value="7">7分</option>
								<option value="8">8分</option>
								<option value="9">9分</option>
								<option value="10">10分</option>
								<option value="11">11分</option>
								<option value="12">12分</option>
								<option value="13">13分</option>
								<option value="14">14分</option>
								<option value="15">15分</option>
								<option value="16">16分</option>
								<option value="17">17分</option>
								<option value="18">18分</option>
								<option value="19">19分</option>
								<option value="20">20分</option>
							</select>
						</div>
					</div>
				</div>
				<!--规则-->
				<div class="layui-row">
					<div class="layui-col-xs2">规则:</div>
					<div class="layui-col-xs10">
						<input type="radio" name="guize" value="1" title="牛牛x3牛九x2牛八x2" checked>
						<input type="radio" name="guize" value="2" title="牛牛x4牛九x3牛八x2牛七x2">
					</div>
				</div>
				<!--牌型-->
				<div class="layui-row">
					<div class="layui-col-xs2">牌型:</div>
					<div class="layui-col-xs10">
							<input type="checkbox" name="paixing" title="四花牛(4倍)" lay-skin="primary" value="shn">
							<input type="checkbox" name="paixing" title="五花牛(5倍)" lay-skin="primary" value="whn">
							<input type="checkbox" name="paixing" title="顺子牛(6倍)" lay-skin="primary" value="szn">
							<input type="checkbox" name="paixing" title="同花牛(6倍)" lay-skin="primary" value="thn">
							<input type="checkbox" name="paixing" title="葫芦牛(6倍)" lay-skin="primary" value="hln">
							<input type="checkbox" name="paixing" title="炸弹牛(6倍)" lay-skin="primary" value="zdn">
							<input type="checkbox" name="paixing" title="同花顺(7倍)" lay-skin="primary" value="ths">
							<input type="checkbox" name="paixing" title="五小牛(8倍)" lay-skin="primary" value="wxn">
							<input type="checkbox" name="paixing" title="五小炸弹牛(10倍)" lay-skin="primary" value="wxzdn">
					</div>
				</div>
				<!--倍数-->
				<div class="layui-row">
					<div class="layui-col-xs2">倍数:</div>
					<div class="layui-col-xs10">
						<input type="checkbox" name="beishu" title="1倍" lay-skin="primary" value="1" checked>
						<input type="checkbox" name="beishu" title="2倍" lay-skin="primary" value="2" checked>
						<input type="checkbox" name="beishu" title="3倍" lay-skin="primary" value="3">
						<input type="checkbox" name="beishu" title="4倍" lay-skin="primary" value="4" checked>
						<input type="checkbox" name="beishu" title="5倍" lay-skin="primary" value="5">
						<input type="checkbox" name="beishu" title="6倍" lay-skin="primary" value="6" checked>
						<input type="checkbox" name="beishu" title="7倍" lay-skin="primary" value="7">
						<input type="checkbox" name="beishu" title="8倍" lay-skin="primary" value="8">
						<input type="checkbox" name="beishu" title="9倍" lay-skin="primary" value="9">
						<input type="checkbox" name="beishu" title="10倍" lay-skin="primary" value="10">
					</div>
				</div>
				<!--时间-->
				<div class="layui-row">
					<div class="layui-col-xs2">时间:</div>
					<div class="layui-col-xs10">
						<div class="layui-col-xs6">
							<div class="layui-col-xs5">准备:</div>
							<div class="layui-col-xs7">
								<select name="zhunbei" lay-verify="required">
									<option value="5">5秒</option>
									<option value="10" selected>10秒</option>
									<option value="15">15秒</option>
									<option value="20">20秒</option>
								</select>
							</div>
						</div>
						<div class="layui-col-xs6">
							<div class="layui-col-xs5">抢庄:</div>
							<div class="layui-col-xs7">
								<select name="qiangzhuang" lay-verify="required">
									<option value="5">5秒</option>
									<option value="10" selected>10秒</option>
									<option value="15">15秒</option>
									<option value="20">20秒</option>
								</select>
							</div>
						</div>
						<div class="layui-col-xs6">
							<div class="layui-col-xs5">下注:</div>
							<div class="layui-col-xs7">
								<select name="xiazhu" lay-verify="required">
									<option value="5">5秒</option>
									<option value="10" selected>10秒</option>
									<option value="15">15秒</option>
									<option value="20">20秒</option>
								</select>
							</div>
						</div>
						<div class="layui-col-xs6">
							<div class="layui-col-xs5">摊牌:</div>
							<div class="layui-col-xs7">
								<select name="tanpai" lay-verify="required">
									<option value="5">5秒</option>
									<option value="10" selected>10秒</option>
									<option value="15">15秒</option>
									<option value="20">20秒</option>
								</select>
							</div>
						</div>
					</div>
				</div>
				<!--局数-->
				<div class="layui-row">
					<div class="layui-col-xs2">局数:</div>
					<div class="layui-col-xs10">
						<input type="radio" name="jushu" value="1" title="10局x1房卡" checked>
						<input type="radio" name="jushu" value="2" title="20局x2房卡">
					</div>
				</div>
				<!--上庄-->
				<div class="layui-row shangzhuang">
					<div class="layui-col-xs2">上庄:</div>
					<div class="layui-col-xs10">
						<div class="layui-row">
							<input type="radio" name="shangzhuang" value="100" title="100" checked class="layui-col-xs4">
							<input type="radio" name="shangzhuang" value="300" title="300" class="layui-col-xs4">
							<input type="radio" name="shangzhuang" value="500" title="500" class="layui-col-xs4">
							<input type="radio" name="shangzhuang" value="1000" title="1000" class="layui-col-xs4">
							<input type="radio" name="shangzhuang" value="2000" title="2000" class="layui-col-xs4">
							<input type="radio" name="shangzhuang" value="999999" title="无" class="layui-col-xs4">
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>

	<div class="layui-form-item">
		<div class="layui-input-block">
			<button class="layui-btn" onclick="create()">保存</button>
		</div>
	</div>
</body>
</html>
<script type="text/javascript">
	layui.use(['form','layer','element'],function(){
		$ = layui.jquery;
		var form = layui.form;
		layer = layui.layer;
		var element = layui.element;
		//初始玩法为明牌抢庄
		var wanfa = 0;
		var difen = 1;
		var shangzhuang = 0;
		rule(wanfa);
		element.on('tab(docDemoTabBrief)', function(data){
            //console.log(data);
            var index = data.index;
            rule(index);
        });

	});

	//切换玩法
	function rule(index){
		//console.log(index);
		wanfa = index;
		if(wanfa ==3){
			$('.shangzhuang').show();
		}else{
			$('.shangzhuang').hide();
		}
	}

	//创建房间
	function create(){
		var gameId = $.trim($('input[name="gameId"]').val());
		if(!gameId){
			layer.msg('请重新选择游戏',{'icon':2,'anim':6});
			return;
		}
		//底分
		var difenArr = [];
		difenArr[0] =  $.trim($('input[name="difen"]:checked').val()) * 1;
		difenArr[1] = $.trim($('select[name="difen"]').val()) * 1;
		difenArr.sort(function(a,b){
			return a-b;
		})
		var difen = difenArr[difenArr.length - 1];
		if(difen <= 0 || !difen){
			layer.msg('请选择底分',{'icon':2,'anim':6});
			return;
		}
		//console.log(difen);
		var guize = $.trim($('input[name="guize"]:checked').val()) * 1;
		//console.log(guize);
		var paixingArr = [];
		$('input[name="paixing"]:checked').each(function(){
			paixingArr.push($(this).val());
		});
		//console.log(paixingArr);
		var beishuArr = [];
		$('input[name="beishu"]:checked').each(function(){
			beishuArr.push($(this).val()* 1);
		});
		if(beishuArr.length !== 4){
			layer.msg('请选择任意4个倍数',{'icon':2,'anim':6});
			return;
		}
		//console.log(beishuArr);
		zhunbei = $.trim($('select[name="zhunbei"]').val())* 1;
		qiangzhuang = $.trim($('select[name="qiangzhuang"]').val())* 1;
		xiazhu = $.trim($('select[name="xiazhu"]').val())* 1;
		tanpai = $.trim($('select[name="tanpai"]').val())* 1;
		shijianArr = [zhunbei,qiangzhuang,xiazhu,tanpai];
		//console.log(shijianArr);
		var jushu = $.trim($('input[name="jushu"]:checked').val())* 1;
		var needHouseCard = 0;
		if(jushu == 1){
			needHouseCard = 1;
		}else if(jushu == 2){
			needHouseCard = 2;
		}
		//console.log(jushu);
		if(wanfa == 3){
			shangzhuang = $.trim($('input[name="shangzhuang"]:checked').val())* 1;
		}else{
			shangzhuang = 0;
		}
		var conf = {
				'wanfa' : wanfa,
				'difen' : difen,
				'guize' : guize,
				'paixing' : paixingArr,
				'beishu' : beishuArr,
				'shijian' : shijianArr,
				'jushu' : jushu,
				'shangzhuang' : shangzhuang
			}
		$.post('/index.php/index/index/createAjax',{gameId:gameId,conf:JSON.stringify(conf),needHouseCard:needHouseCard},function(res){
			if(res.code == 0){
				layer.msg(res.msg,{'icon':2,'anim':6});
			}else{
				layer.msg(res.msg,{'icon':1});
				setTimeout(function(){parent.window.location.href = '/index.php/index/index/wait?roomId='+res.data.id;},1000);
			}
		},'json')
	}

</script>