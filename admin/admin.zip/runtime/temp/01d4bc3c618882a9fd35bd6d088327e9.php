<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"D:\phpstudy\PHPTutorial\WWW\admin\public/../application/index\view\sendcard\index.html";i:1544411764;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>赠送房卡</title>
    <link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
    <script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
    <style>
        *{margin: 0;padding: 0;}
        html,body{width: 100%;height: 100%;}
        body{position: absolute;top: 0;left: 0;background:url('/static/images/bg_sendCards.jpg') 100% 100%;background-size: 100% 100%;}
        .input-bg{width: 80%;height: 2rem;margin-top: 4rem;margin-left: 10%;background: rgba(0, 0, 0, 0.5);border-radius: 0.5rem;}
        .input-bg input{width: 80%;height: 2rem; float: left;border: none;background: rgba(0, 0, 0,0.1);margin-left: 5%;font-size: 1.2rem;line-height: 2rem;color: #f5f5f5;}
        .input-bg p{width: 15%;height: 2rem;line-height:2rem;float: left;text-align: center;background: rgba(0, 0, 0,0.1);color: #f5f5f5;}
        .btn-send-card-div{margin-top: 80%;text-align: center;}
        .btn-send-cards{width: 8rem;height: 2.5rem;}
    </style>
</head>
<body>
    <div class="layui-row">
        <button class="layui-btn layui-btn-sm layui-btn-normal" onclick="back()">
            <i class="layui-icon">&#xe65c;</i>
        </button>
    </div>
    <div class="layui-row">
        <div class="input-bg">
            <input type="number" name="card" placeholder="输入房卡数量" value="" />
            <p>张</p>
        </div>
    </div>

    <div class="layui-row btn-send-card-div">
        <img src="/static/images/btn_sendCards.png" class="btn-send-cards" onclick="sendCard()"/>
    </div>
    <script>
        layui.use(['layer'],function(){
			layer = layui.layer;
			$ = layui.jquery;
		});
        
        function back(){
            window.location.href = "/index.php/index/Personal/index";
        }

        function sendCard(){
            var card_num = $.trim($('input[name="card"]').val());
            //console.log(card_num);
            if(card_num <= 0){
                layer.msg('数量必须大于0',{'icon':2,'anim':6});
                return;
            }
            $.post('/index.php/index/Sendcard/sendCardAjax',{num:card_num},function(res){
                console.log(res);
                if(res.code == 0){
                    layer.msg(res.msg,{'icon':2,'anim':6});
                    return;
                }else{
                    //layer.msg(res.msg,{'icon':1});
                    setTimeout(function(){
                        window.location.href = "/index.php/index/Sendcard/send?id="+res.data;
                    },1000);
                }
            },'json')
        }
    </script>
</body>
</html>