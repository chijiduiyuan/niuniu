<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"D:\phpstudy\PHPTutorial\WWW\admin\public/../application/admins\view\manage\index.html";i:1543290976;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
    <link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
    <script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
    <style type="text/css">
		.header span{background: #009688;margin-left: 30px;padding: 10px;color:#ffffff;}
		.header div{border-bottom: solid 2px #009688;margin-top: 8px;}
		.header button{float: right;margin-top: -5px;}
	</style>
</head>
<body>
    <div class="header">
		<span>管理员列表</span>
		<button class="layui-btn layui-btn-sm" onclick="add()">添加</button>
		<div></div>
	</div>

	<table class="layui-table">
		<thead>
			<tr>
				<th>平台</th>
                <th>级别</th>
                <th>用户名</th>
				<th>状态</th>
				<th>操作</th>
			</tr>
		</thead>
		<tbody>
			<?php if(is_array($data['data']['lists']) || $data['data']['lists'] instanceof \think\Collection || $data['data']['lists'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['data']['lists'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
			<tr>
				<td><?php echo isset($vv['agent'])?$vv['agent']['title']:''; ?></td>
                <td><?php echo isset($vv['role'])?$vv['role']['title']:''; ?></td>
				<td><?php echo isset($vv['username'])?$vv['username']:''; ?></td>
				<td><?php echo isset($vv['status']) && $vv['status'] == 1 && $vv['agent']['status'] == 1 && $vv['role']['status'] == 1 ? "正常":"<span style='color:red'>禁用</span>"; ?></td>
				<td>
					<button class="layui-btn layui-btn-xs btn-edit" onclick="edit(<?php echo $vv['id']; ?>);">编辑</button>
				</td>
			</tr>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</tbody>
    </table>
    <div id="pages"></div>


    <script>
        layui.use(['layer','laypage'],function(){
			layer = layui.layer;
			$ = layui.jquery;
			laypage = layui.laypage;

			laypage.render({
			    elem: 'pages',
				count:<?php echo $data['data']['total']; ?>,               //数据总数
				limit:<?php echo $data['perPage']; ?>,             //每页显示的条数
				curr:<?php echo $data['current']; ?>,
				jump: function(obj, first){
			    if(!first){
			    	searchs(obj.curr);
			    }
			  }
			});
		});

        function searchs(curpage){
            var url = "/admins.php/admins/manage/manageList?page="+curpage;
            window.location.href = url;
        }

        //编辑
		function edit(id){
			layer.open({
			  type: 2,
			  title: '编辑管理员',
			  shade: 0.3,
			  area: ['500px', '350px'],
			  content: '/admins.php/admins/Manage/edit?id='+id
			});
		}

		//添加
		function add(){
			layer.open({
			  type: 2,
			  title: '添加管理员',
			  shade: 0.3,
			  area: ['500px', '400px'],
			  content: '/admins.php/admins/manage/add'
			});
		}
    </script>
</body>
</html>