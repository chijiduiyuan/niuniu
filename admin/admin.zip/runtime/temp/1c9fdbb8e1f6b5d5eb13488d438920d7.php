<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"D:\phpstudy\PHPTutorial\WWW\admin\public/../application/index\view\index\wait.html";i:1543386345;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>邀请</title>
    <link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
    <script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
    <style>
        *{margin: 0;padding: 0;}
        html{width: 100%;height: 100%;}
        body{background:url('/static/images/bg.png') 100% 100%;background-size: 100% 100%;}
        .main{width: 80%;background-color: rgba(0, 0, 0, 0.5);margin-left: 10%;margin-top: 30%;}
        .div-row{min-height: 1.5rem;}
    </style>
</head>
<body>
    <div class="container main">
        <div class="layui-row div-row">
            <div>房间号:<?php echo $data['room']['id']; ?></div>
        </div>
        <div class="layui-row div-row">
            <div>游戏:<?php echo $data['room']['game_id']['title']; ?></div>
        </div>
        <div class="layui-row div-row">
            <div>房主:<?php echo $data['room']['create_uid']['nickname']; ?></div>
        </div>
        <div class="layui-row div-row">
            <?php if($data['room']['game_id']['type'] == 'nn'): ?>
                <div>玩法:<?php if($data['room']['conf']['wanfa'] == 0){ echo '明牌抢庄';} if($data['room']['conf']['wanfa'] == 1){ echo '牛牛上庄';} if($data['room']['conf']['wanfa'] == 2){ echo '自由抢庄';} if($data['room']['conf']['wanfa'] == 3){ echo '固定庄家';}?></div>
                <div>底分:<?php echo $data['room']['conf']['difen']; ?>分</div>
                <div>规则:<?php if($data['room']['conf']['guize'] == 1){ echo '牛牛x3牛九x2牛八x2';} if($data['room']['conf']['guize'] == 2){ echo '牛牛x4牛九x3牛八x2牛七x2';} ?></div>
                <?php if(is_array($data['room']['conf']['paixing'])){ ?>
                <div>牌型:<?php foreach($data['room']['conf']['paixing'] as $key => $value){echo $value.',';} ?></div>
                <?php } if(is_array($data['room']['conf']['beishu'])){ ?>
                <div>倍数:<?php foreach($data['room']['conf']['beishu'] as $key => $value){echo $value.',';} ?></div>
                <?php } ?>
                <div>时间:<?php echo '准备时间:'.$data['room']['conf']['shijian'][0].'s,抢庄时间:'.$data['room']['conf']['shijian'][1].'s,下注时间:'.$data['room']['conf']['shijian'][2].'s,摊牌时间:'.$data['room']['conf']['shijian'][3].'s' ?></div>
                <div>局数:<?php if($data['room']['conf']['jushu'] == 1){ echo '10局x1房卡';} if($data['room']['conf']['jushu'] == 2){ echo '20局x2房卡';} ?></div>
            <?php endif; ?>
        </div>
        <div class="layui-row div-row">
            <div>创建时间:<?php echo date('Y-m-d H:i:s',$data['room']['create_time']); ?></div>
        </div>
        <div class="layui-row">
            <button class="layui-btn" onclick="joinRoom()" >进入游戏</button>
        </div>
    </div>

    <script>
        layui.use('layer',function(){
			layer = layui.layer;
			$ = layui.jquery;
		});

        function joinRoom(){
            var url = "<?php echo $data['server_name']; ?>";
            var roomNum = "<?php echo $data['room']['id']; ?>";
            var gameType = "<?php echo $data['room']['game_id']['type']; ?>";
            var uid = "<?php echo $data['uid']; ?>";
            var status = "<?php echo $data['room']['status']; ?>";
            if(status == 2){
                layer.msg('房间已经结束',{'icon':2,'anim':6});
                return;
            }else{
                window.location.href = "http://"+url+"/game/"+gameType+"/index.html/?roomNum="+roomNum+"&uid="+uid;
            }
        }
    </script>
</body>
</html>