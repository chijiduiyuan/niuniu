<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"D:\phpstudy\PHPTutorial\WWW\admin\public/../application/admins\view\game\index.html";i:1543290933;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
    <link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
    <script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
    <style type="text/css">
		.header span{background: #009688;margin-left: 30px;padding: 10px;color:#ffffff;}
		.header div{border-bottom: solid 2px #009688;margin-top: 8px;}
		.header button{float: right;margin-top: -5px;}
	</style>
</head>
<body>
    <div class="header">
		<span>游戏列表</span>
		<button class="layui-btn layui-btn-sm" onclick="add()">添加</button>
		<div></div>
	</div>

	<table class="layui-table">
		<thead>
			<tr>
				<th>平台</th>
				<th>排序</th>
				<th>游戏名</th>
				<th>类型</th>
				<th>游戏代号</th>
				<th>缩略图</th>
				<th>状态</th>
				<th>创建时间</th>
				<th>操作</th>
			</tr>
		</thead>
		<tbody>
			<?php if(is_array($data['data']['lists']) || $data['data']['lists'] instanceof \think\Collection || $data['data']['lists'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['data']['lists'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
			<tr>
				<td><?php echo isset($vv['agent'])?$vv['agent']['title']:''; ?></td>
				<td><?php echo isset($vv['order'])?$vv['order']:''; ?></td>
                <td><?php echo isset($vv['title'])?$vv['title']:''; ?></td>
				<td><?php echo isset($vv['type'])?$vv['type']:''; ?></td>
				<td><?php echo isset($vv['code'])?$vv['code']:''; ?></td>
				<td><img src="<?php echo isset($vv['pic']) ? "/static/images/game/".$vv['pic'] : ""; ?>" style="height: 50px;"/></td>
				<td><?php echo isset($vv['status']) && $vv['status'] == 1? "上线":"<span style='color:red'>下线</span>"; ?></td>
				<td><?php echo date('Y-m-d H:i:s',$vv['create_time']); ?></td>
				<td>
					<button class="layui-btn layui-btn-xs" onclick="edit(<?php echo $vv['id']; ?>)">编辑</button>
				</td>
			</tr>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</tbody>
    </table>
    <div id="pages"></div>


    <script>
        layui.use(['layer','laypage'],function(){
			layer = layui.layer;
			$ = layui.jquery;
			laypage = layui.laypage;

			laypage.render({
			    elem: 'pages',
				count:<?php echo $data['data']['total']; ?>,               //数据总数
				limit:<?php echo $data['perPage']; ?>,             //每页显示的条数
				curr:<?php echo $data['current']; ?>,
				jump: function(obj, first){
			    if(!first){
			    	searchs(obj.curr);
			    }
			  }
			});
		});

        function searchs(curpage){
            var url = "/admins.php/admins/game/index?page="+curpage;
            window.location.href = url;
        }

        //编辑
		function edit(id){
			layer.open({
			  type: 2,
			  title: '编辑游戏',
			  shade: 0.3,
			  area: ['500px', '350px'],
			  content: '/admins.php/admins/game/edit?id='+id
			});
		}

		//添加
		function add(){
			layer.open({
			  type: 2,
			  title: '添加游戏',
			  shade: 0.3,
			  area: ['500px', '550px'],
			  content: '/admins.php/admins/game/add'
			});
		}
    </script>
</body>
</html>