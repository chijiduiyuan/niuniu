<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:89:"D:\phpstudy\PHPTutorial\WWW\admin\public/../application/admins\view\user\card_record.html";i:1543290604;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
    <link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
    <script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
    <style type="text/css">
		.header span{background: #009688;margin-left: 30px;padding: 10px;color:#ffffff;}
		.header div{border-bottom: solid 2px #009688;margin-top: 8px;}
	</style>
</head>
<body>
    <div class="header">
		<span>充值记录</span>
		<div></div>
	</div>

	<table class="layui-table">
		<thead>
			<tr>
				<th>id</th>
				<th>操作者</th>
				<th>领取人</th>
				<th>房卡数量</th>
				<th>价格</th>
				<th>创建时间</th>
			</tr>
		</thead>
		<tbody>
			<?php if(is_array($data['data']['lists']) || $data['data']['lists'] instanceof \think\Collection || $data['data']['lists'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['data']['lists'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
			<tr>
				<td><?php echo $vv['id']; ?></td>
				<td>
					<p>操作平台:<?php echo $vv['operator']['agent']['title']; ?></p>
					<p>账号:<?php echo $vv['operator']['username']; ?></p>
				</td>
				<td>
					<img src="<?php echo isset($vv['receiptor']['avatar'])?$vv['receiptor']['avatar']:''; ?>" alt="" style="width:50px;height:50px;">
					<p>玩家平台:<?php echo $vv['receiptor']['agent']['title']; ?></p>
					<p>uid:<?php echo $vv['receiptor']['uid']; ?></p>
					<p>昵称:<?php echo $vv['receiptor']['nickname']; ?></p>
				</td>
				<td><?php echo $vv['num']; ?></td>
				<td><?php echo $vv['price']; ?></td>
				<td><?php echo date('Y-m-d H:i:s',$vv['create_time']); ?></td>
			</tr>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</tbody>
    </table>
    <div id="pages"></div>


    <script>
        layui.use(['layer','laypage'],function(){
			layer = layui.layer;
			$ = layui.jquery;
			laypage = layui.laypage;

			laypage.render({
			    elem: 'pages',
				count:<?php echo $data['data']['total']; ?>,               //数据总数
				limit:<?php echo $data['perPage']; ?>,                //每页显示的条数
				curr:<?php echo $data['current']; ?>,
				jump: function(obj, first){
			    if(!first){
			    	searchs(obj.curr);
			    }
			  }
			});
		});

        function searchs(curpage){
            var url = "/admins.php/admins/User/cardRecord?page="+curpage;
            window.location.href = url;
        }
        //修改玩家资料
		function edit(uid){
			layer.open({
			  type: 2,
			  title: '编辑玩家资料',
			  shade: 0.3,
			  area: ['500px', '350px'],
			  content: '/admins.php/admins/User/edit?uid='+uid
			});
		}

        //充值
        function pay(uid){
			layer.open({
			  type: 2,
			  title: '房卡充值',
			  shade: 0.3,
			  area: ['500px', '450px'],
			  content: '/admins.php/admins/User/pay?uid='+uid
			});
		}
    </script>
</body>
</html>