<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"D:\phpstudy\PHPTutorial\WWW\admin\public/../application/admins\view\manage\edit.html";i:1543025301;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>修改玩家</title>
	<link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
	<script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
</head>
<body style="padding: 10px;">
	<form class="layui-form">
        <input type="hidden" name="id" value="<?php echo $manageInfo['id']; ?>">
        <div class="layui-form-item">
            <label class="layui-form-label">用户名</label>
            <div class="layui-input-block">
                <input type="text" class="layui-input" value="<?php echo isset($manageInfo['username'])?$manageInfo['username']:''; ?>" readonly>
            </div>
        </div>
		<div class="layui-form-item">
            <label class="layui-form-label">平台</label>
            <div class="layui-input-block">
                <select name="agent" lay-verify="">
					<option value="0">请选择一个平台</option>
					<?php if(is_array($agentList) || $agentList instanceof \think\Collection || $agentList instanceof \think\Paginator): $i = 0; $__LIST__ = $agentList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
					<option value="<?php echo $vv['id']; ?>" <?php if($vv['id']==$manageInfo['agent']){echo 'selected';}?> ><?php echo $vv['title']; ?></option>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</select>
            </div>
		</div>
		<div class="layui-form-item">
            <label class="layui-form-label">分组</label>
            <div class="layui-input-block">
                <select name="role" lay-verify="">
					<option value="0">请选择一个分组</option>
					<?php if(is_array($roleList) || $roleList instanceof \think\Collection || $roleList instanceof \think\Paginator): $i = 0; $__LIST__ = $roleList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
					<option value="<?php echo $vv['id']; ?>" <?php if($vv['id']==$manageInfo['role']){echo 'selected';}?> ><?php echo $vv['title']; ?></option>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</select>
            </div>
        </div>
		<div class="layui-form-item">
			<label class="layui-form-label">状态</label>
			<div class="layui-input-inline">
                <input type="radio" layui-skin="primary" name="status" title="正常"  value="1" <?php if($manageInfo['status']==1){echo 'checked';}?>>
				<input type="radio" layui-skin="primary" name="status" title="禁用"  value="0" <?php if($manageInfo['status']==0){echo 'checked';}?>>
			</div>
		</div>
	</form>
	<div class="layui-form-item">
		<div class="layui-input-block">
			<button class="layui-btn" onclick="save()">保存</button>
		</div>
	</div>
</body>
</html>
<script type="text/javascript">
	layui.use(['form','layer'],function(){
		$ = layui.jquery;
		var form = layui.form;
		layer = layui.layer;
	});

    // 保存
	function save(){
		var agent = $.trim($('select[name="agent"]').val());
		var role = $.trim($('select[name="role"]').val());
		if(agent == 0){
			layer.msg('请选择平台',{'icon':2,'anim':6});
			return;
		}
		if(role == 0){
			layer.msg('请选择分组',{'icon':2,'anim':6});
			return;
		}
		$.post('/admins.php/admins/manage/save',$('form').serialize(),function(res){
			if(res.code==0){
				layer.msg(res.msg,{'icon':2,'anim':2});
			}else{
				layer.msg(res.msg,{'icon':1});
				setTimeout(function(){parent.window.location.reload();},1000);
			}
		},'json');
	}
</script>