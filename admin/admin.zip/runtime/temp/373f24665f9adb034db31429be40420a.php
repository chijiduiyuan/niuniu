<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"D:\phpstudy\PHPTutorial\WWW\admin\public/../application/index\view\index\ddz.html";i:1541991738;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>创建房间</title>
	<link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
	<script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
	<style>
		.wanfa{height: 4.5rem;}
	</style>
</head>
<body style="padding: 10px;">
	<form class="layui-form">
		<input type="hidden" name="gameId" value="<?php echo $game['id']; ?>">
		<!--底分-->
        <div class="layui-row">
            <div class="layui-col-xs2">底分:</div>
            <div class="layui-col-xs10">
                <input type="radio" name="difen" value="1" title="1分">
                <input type="radio" name="difen" value="2" title="2分">
                <input type="radio" name="difen" value="5" title="5分" checked>
                <input type="radio" name="difen" value="10" title="10分">
            </div>
		</div>
		<!--规则-->
        <div class="layui-row">
            <div class="layui-col-xs2">规则:</div>
            <div class="layui-col-xs10">
                <input type="checkbox" name="guize" value="jiabei" title="加倍" lay-skin="primary">
                <input type="checkbox" name="guize" value="mingpai" title="明牌" lay-skin="primary">
            </div>
		</div>
		<!--封顶-->
        <div class="layui-row">
            <div class="layui-col-xs2">封顶:</div>
            <div class="layui-col-xs10">
                <input type="radio" name="fengding" value="0" title="无" checked>
                <input type="radio" name="fengding" value="250" title="250">
                <input type="radio" name="fengding" value="500" title="500">
                <input type="radio" name="fengding" value="1000" title="1000">
            </div>
		</div>
		<!--时间-->
        <div class="layui-row">
            <div class="layui-col-xs2">时间:</div>
            <div class="layui-col-xs10">
                <div class="layui-col-xs6">
					<div class="layui-col-xs5">出牌:</div>
					<div class="layui-col-xs7">
						<select name="chupai" lay-verify="required">
							<option value="10">10秒</option>
							<option value="15" selected>15秒</option>
							<option value="20">20秒</option>
							<option value="25">25秒</option>
							<option value="30">30秒</option>
						</select>
					</div>
				</div>
            </div>
		</div>
		<!--局数-->
        <div class="layui-row">
            <div class="layui-col-xs2">局数:</div>
            <div class="layui-col-xs10">
                <input type="radio" name="jushu" value="1" title="6局x1房卡" checked>
                <input type="radio" name="jushu" value="2" title="12局x2房卡">
            </div>
		</div>
	</form>

	<div class="layui-form-item">
		<div class="layui-input-block">
			<button class="layui-btn" onclick="create()">保存</button>
		</div>
	</div>
</body>
</html>
<script type="text/javascript">
	layui.use(['form','layer','element'],function(){
		$ = layui.jquery;
		var form = layui.form;
		layer = layui.layer;
		var element = layui.element;
	});

	//创建房间
	function create(){
		var gameId = $.trim($('input[name="gameId"]').val());
		if(!gameId){
			layer.msg('请重新选择游戏',{'icon':2,'anim':6});
			return;
		}
		var difen = $.trim($('input[name="difen"]:checked').val());
		var guizeArr = [];
		$('input[name="guize"]:checked').each(function(){
			guizeArr.push($(this).val());
		});
        var fengding = $.trim($('input[name="fengding"]:checked').val());
		var chupai = $.trim($('select[name="chupai"]').val());
		shijianArr = [chupai];
		var jushu = $.trim($('input[name="jushu"]:checked').val());
		var needHouseCard = 0;
		if(jushu == 1){
			needHouseCard = 1;
		}else if(jushu == 2){
			needHouseCard = 2;
		}
		var conf = {
				'difen' : difen,
				'guize' : JSON.stringify(guizeArr),
				'fengding' : fengding,
				'shijian' : JSON.stringify(shijianArr),
				'jushu' : jushu
			}
		$.post('/index.php/index/index/createAjax',{gameId:gameId,conf:JSON.stringify(conf),needHouseCard:needHouseCard},function(res){
			if(res.code > 0){
				layer.msg(res.msg,{'icon':2,'anim':6});
			}else{
				layer.msg(res.msg,{'icon':1});
				setTimeout(function(){parent.window.location.href = '/index.php/index/index/wait?roomId='+res.data;},1000);
			}
		},'json')
	}

</script>