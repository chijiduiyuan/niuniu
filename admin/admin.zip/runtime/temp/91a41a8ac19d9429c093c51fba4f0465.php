<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"D:\phpstudy\PHPTutorial\WWW\admin\public/../application/index\view\cardgift\index.html";i:1544422231;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>礼包记录</title>
    <link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
    <script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
    <style>
       *{margin: 0;padding: 0;}
        html,body{width: 100%;height: 100%;}
        body{position: absolute;top: 0;left: 0;}
        .layui-tab-title{width: 60%;margin-left: 20%;border: none;}
        .layui-this{background-color: #FFB800;color: #f5f5f5;}
        .info{width: 90%;margin-left: 5%;border-top: 1px solid #000;height: 4rem;}
        .info p{height: 2rem;line-height: 2rem;}
    </style>
</head>
<body>
    <div class="layui-row">
        <button class="layui-btn layui-btn-sm layui-btn-normal" onclick="back()">
            <i class="layui-icon">&#xe65c;</i>
        </button>
    </div>

    <div class="layui-tab">
        <ul class="layui-tab-title">
            <li class="layui-this">发出房卡</li>
            <li>收到房卡</li>
        </ul>
        <div class="layui-tab-content">
            <div class="layui-tab-item layui-show">
                <?php if(is_array($data['send']) || $data['send'] instanceof \think\Collection || $data['send'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['send'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
                <div class="layui-row info">
                    <div class="layui-col-xs10">
                        <p><?php echo $vv['sender']['nickname']; ?></p>
                        <p><?php echo date('Y-m-d H:i:s',$vv['send_time']); ?></p>
                    </div>
                    <div class="layui-col-xs2">
                        <p><?php echo $vv['card_num']; ?>张</p>
                        <p><?php echo isset($vv['receiver']) ? '<button class="layui-btn layui-btn-sm" onclick="cardInfo('.$vv["id"].')">已领取</button>' : '<button class="layui-btn layui-btn-sm layui-btn-primary" onclick="cardInfo('.$vv["id"].')">未领取</button>'; ?></p>
                    </div>
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
            <div class="layui-tab-item">
                <?php if(is_array($data['receive']) || $data['receive'] instanceof \think\Collection || $data['receive'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['receive'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
                <div class="layui-row info">
                    <div class="layui-col-xs10">
                        <p><?php echo $vv['sender']['nickname']; ?></p>
                        <p><?php echo date('Y-m-d H:i:s',$vv['send_time']); ?></p>
                    </div>
                    <div class="layui-col-xs2">
                        <p><?php echo $vv['card_num']; ?>张</p>
                        <p><button class="layui-btn layui-btn-sm layui-btn-primary" onclick="cardInfo(<?php echo $vv['id']; ?>)">已领取</button></p>
                    </div>
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
    </div>

    <script>
        layui.use('element', function(){
            var element = layui.element;
            layer = layui.layer;
			$ = layui.jquery;
        });

        function back(){
            window.location.href = "/index.php/index/Personal/index";
        }

        function cardInfo(id){
            window.location.href = "/index.php/index/Sendcard/send?id="+id;
        }
    </script>
</body>
</html>