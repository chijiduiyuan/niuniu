<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"D:\phpstudy\PHPTutorial\WWW\admin\public/../application/admins\view\site\index.html";i:1543052042;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
    <link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
    <script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
    <style type="text/css">
		.header span{background: #009688;margin-left: 30px;padding: 10px;color:#ffffff;}
		.header div{border-bottom: solid 2px #009688;margin-top: 8px;}
		.header button{float: right;margin-top: -5px;}
	</style>
</head>
<body>
    <div class="header">
		<span>站点配置</span>
		<button class="layui-btn layui-btn-sm" onclick="add()">添加</button>
		<div></div>
	</div>

	<table class="layui-table">
		<thead>
			<tr>
				<th>平台</th>
                <th>appid</th>
				<th>secret</th>
				<th>url</th>
				<th>默认房卡</th>
				<th>时间</th>
				<th>操作</th>
			</tr>
		</thead>
		<tbody>
			<?php if(is_array($siteList) || $siteList instanceof \think\Collection || $siteList instanceof \think\Paginator): $i = 0; $__LIST__ = $siteList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
			<tr>
				<td><?php echo $vv['agent']['title']; ?></td>
				<td><?php echo $vv['appid']; ?></td>
				<th><?php echo $vv['appsecret']; ?></th>
				<th><?php echo $vv['url']; ?></th>
				<th><?php echo $vv['card']; ?></th>
				<td><?php echo date('Y-m-d H:i:s',$vv['create_time']); ?></td>
				<td>
					<button class="layui-btn layui-btn-xs" onclick="edit(<?php echo $vv['id']; ?>)">编辑</button>
				</td>
			</tr>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</tbody>
    </table>
    <div id="pages"></div>


    <script>
        layui.use(['layer','laypage'],function(){
			layer = layui.layer;
			$ = layui.jquery;
			laypage = layui.laypage;

			laypage.render({
			    elem: 'pages',
				count:<?php echo $count; ?>,               //数据总数
				limit:<?php echo $perPage; ?>,             //每页显示的条数
				curr:<?php echo $current; ?>,
				jump: function(obj, first){
			    if(!first){
			    	searchs(obj.curr);
			    }
			  }
			});
		});

        function searchs(curpage){
            var url = "/admins.php/admins/Site/index?page="+curpage;
            window.location.href = url;
        }

        //编辑
		function edit(id){
			layer.open({
			  type: 2,
			  title: '编辑站点配置',
			  shade: 0.3,
			  area: ['500px', '350px'],
			  content: '/admins.php/admins/Site/edit?id='+id
			});
		}

		//添加
		function add(){
			layer.open({
			  type: 2,
			  title: '添加站点配置',
			  shade: 0.3,
			  area: ['500px', '400px'],
			  content: '/admins.php/admins/Site/add'
			});
		}
    </script>
</body>
</html>