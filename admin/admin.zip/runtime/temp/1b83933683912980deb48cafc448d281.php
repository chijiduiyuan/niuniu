<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"D:\phpstudy\PHPTutorial\WWW\admin\public/../application/admins\view\site\add.html";i:1543052503;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
	<script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
</head>
<body style="padding: 10px;">
	<form class="layui-form">
		<div class="layui-form-item">
            <label class="layui-form-label">平台</label>
            <div class="layui-input-block">
                <select name="agent" lay-verify="">
					<option value="0">请选择一个平台</option>
					<?php if(is_array($agentList) || $agentList instanceof \think\Collection || $agentList instanceof \think\Paginator): $i = 0; $__LIST__ = $agentList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
					<option value="<?php echo $vv['id']; ?>"><?php echo $vv['title']; ?></option>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</select>
            </div>
		</div>
        <div class="layui-form-item">
			<label class="layui-form-label">appid</label>
			<div class="layui-input-block">
				<input type="text" class="layui-input" name="appid" value="">
			</div>
		</div>
		<div class="layui-form-item">
			<label class="layui-form-label">appsecret</label>
			<div class="layui-input-block">
				<input type="text" class="layui-input" name="appsecret" value="">
			</div>
		</div>
		<div class="layui-form-item">
			<label class="layui-form-label">url</label>
			<div class="layui-input-block">
				<input type="text" class="layui-input" name="url" value="">
			</div>
		</div>
		<div class="layui-form-item">
			<label class="layui-form-label">默认房卡</label>
			<div class="layui-input-block">
				<input type="text" class="layui-input" name="card" value="">
			</div>
        </div>
	</form>
	<div class="layui-form-item">
		<div class="layui-input-block">
			<button class="layui-btn" onclick="save()">保存</button>
		</div>
	</div>
</body>
</html>
<script type="text/javascript">
	layui.use(['form','layer'],function(){
		$ = layui.jquery;
		var form = layui.form;
		layer = layui.layer;
	});

    // 保存
	function save(){
        var agent = $.trim($('select[name="agent"]').val());
		if(agent == 0){
            layer.msg('请选择平台',{'icon':2,'anim':6});
			return;
        }
        var appid = $.trim($('input[name="appid"]').val());
        if(appid == ""){
            layer.msg('请输入appid',{'icon':2,'anim':6});
			return;
        }
		var appsecret = $.trim($('input[name="appsecret"]').val());
        if(appsecret == ""){
            layer.msg('请输入appsecret',{'icon':2,'anim':6});
			return;
        }
		var card = $.trim($('input[name="card"]').val());
        if(card == ""){
            layer.msg('请输入房卡数量',{'icon':2,'anim':6});
			return;
        }
		$.post('/admins.php/admins/Site/addSave',$('form').serialize(),function(res){
			if(res.code==0){
				layer.msg(res.msg,{'icon':2,'anim':2});
			}else{
				layer.msg(res.msg,{'icon':1});
				setTimeout(function(){parent.window.location.reload();},1000);
			}
		},'json');
	}
</script>