<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:88:"D:\phpstudy\PHPTutorial\WWW\admin\public/../application/index\view\roomsearch\index.html";i:1544429281;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>礼包记录</title>
    <link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css">
    <script type="text/javascript" src="/static/plugins/layui/layui.js"></script>
    <style>
       *{margin: 0;padding: 0;}
        html,body{width: 100%;height: 100%;}
        body{position: absolute;top: 0;left: 0;background:url('/static/images/img_bg.png') 100% 100%;background-size: 100% 100%;}
        .game-head{width: 100%;height: 4rem;}
        .category-head{width: 100%;display: inline;white-space: nowrap;overflow-x: scroll;float: left;overflow-y: hidden;background-color: #291C4D;}
        .category-head li{margin-top: 0.5rem;display:inline-block;}
        .category-head li img{width: 4rem;height: 3rem;}
        .title{width: 100%;height: 3rem;background-color: #291C4D;margin-bottom: 0.5rem;}
        .title div{line-height: 3rem;text-align: center;color: #f5f5f5;}
        .tab-content{color: #f5f5f5;}
        .tab-item{width: 100%;height: 3rem;background-color: #291C4D;margin-bottom: 1px;}
        .tab-item div{line-height: 3rem;text-align: center;}
    </style>
</head>
<body>
    <div class="layui-row">
        <button class="layui-btn layui-btn-sm layui-btn-normal" onclick="back()">
            <i class="layui-icon">&#xe65c;</i>
        </button>
    </div>

    <div class="game-head">
        <ul class="category-head">
            <li class="layui-this"><img src="/static/images/all_game.png" onclick="getList(0)"/></li>
            <?php if(is_array($data['gameList']) || $data['gameList'] instanceof \think\Collection || $data['gameList'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['gameList'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
            <li><img src="/static/images/game/<?php echo $vv['pic']; ?>" onclick="getList(<?php echo $vv['id']; ?>)"/></li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>

    <div class="layui-row title">
        <div class="layui-col-xs3">房间号</div>
        <div class="layui-col-xs6">创建时间</div>
        <div class="layui-col-xs3">房间状态</div>
    </div>
    <div class="tab-content">
        <?php if(is_array($data['rooms']) || $data['rooms'] instanceof \think\Collection || $data['rooms'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['rooms'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$va): $mod = ($i % 2 );++$i;?>
        <div class="tab-item">
            <div class="layui-col-xs3"><?php echo $va['id']; ?></div>
            <div class="layui-col-xs6"><?php echo date('Y-m-d H:i:s',$va['create_time']); ?></div>
            <div class="layui-col-xs3">
                <button class="layui-btn layui-btn-sm" onclick="getInfo(<?php echo $va['id']; ?>)">
                    <?php if($va['status'] == 0): ?>
                        未开始
                    <?php elseif($va['status'] == 1): ?>
                        进行中
                    <?php elseif($va['status'] == 2): ?>
                        已结束
                    <?php endif; ?>
                </button>
            </div>
        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>

    <script>
        layui.use('layer', function(){
            layer = layui.layer;
			$ = layui.jquery;
        });
        
        //返回上一级
        function back(){
            window.location.href = "/index.php/index/Personal/index";
        }
        //获取房间列表
        function getList(id){
            window.location.href = "/index.php/index/Roomsearch/index?id="+id;
        }
        //获取房间详情
        function getInfo(id){
            window.location.href = "/index.php/index/Roomsearch/info?id="+id;
        }
    </script>
</body>
</html>