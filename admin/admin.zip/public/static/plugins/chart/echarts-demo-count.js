$(function () {
   
    
    var arr = [];

    //柱形图
    var barChart = echarts.init(document.getElementById("echarts-bar-user"));
    var baroption = {
        title : {
            text: '新老用户'
        },
        tooltip : {
            trigger: 'axis'
        },
        legend: {
            data:['新用户','老用户']
        },
        calculable : true,

        xAxis : [
            {
                type : 'category',
                data : ['10/9','10/10','10/11','10/12','10/13','10/14','10/15']
            }
        ],
        yAxis : [
            {
                type : 'value'
            }
        ],
        series : [
            {
                name:'新用户',
                type:'bar',
                data:[11, 110, 150, 13, 12, 20, 10],
                markPoint : {
                    data : ['']
                },
                markLine : {
                    data : [
                        {type : 'average', name: '平均值'}
                    ]
                }
            },
            {
                name:'老用户',
                type:'bar',
                data:[1, 2, 2, 50, 3, 2, 0],
                markPoint : {
                    data : ['']
                },
                markLine : {
                    data : [
                        {type : 'average', name : '平均值'}
                    ]
                }
            }
        ]
    };
    barChart.setOption(baroption,true);

    //饼图
    var pieRoomToday = echarts.init(document.getElementById("echarts-room-today"));
    var pieoptionRoom = {
        title : {
            text: '今日房间消耗',
            subtext: '',
            x:'center'
        },
        //提示框组件,鼠标移动上去显示的提示内容
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b}: {c} ({d}%)"//模板变量有 {a}、{b}、{c}、{d}，分别表示系列名，数据名，数据值，百分比。
        },
        //图例
        legend: {
            //图例垂直排列
            orient : 'vertical',
            x:'0',
            y:'30',
            //data中的名字要与series-data中的列名对应，方可点击操控
            data:['青牛','朱雀','玄武','青龙','白虎']
        },
        calculable : true,
        series: [
            {
                name:'房间消耗',
                type:'pie',
                //饼状图
                // radius: ['50%', '70%'],
                radius : '55%',
                center: ['50%', '60%'],
                avoidLabelOverlap: false, 
                data:[
                    {value:335, name:'青牛'},
                    {value:310, name:'朱雀'},
                    {value:234, name:'玄武'},
                    {value:135, name:'青龙'},
                    {value:1548, name:'白虎'}
                ]
            }
        ]
        
    };
    pieRoomToday.setOption(pieoptionRoom,true);


    arr.push(barChart);
    arr.push(barChartYestoday);
    arr.push(pieRoomToday);
    arr.push(pieChartToday);
    // 当浏览器窗口大小出现变化时，重新渲染
    $(window).resize(function () {
        for (var i = 0; i < arr.length; i++) {
            arr[i].resize();
        }
    });
  
    // 给tab导航按钮注册事件，让其渲染
    $('#myTabs li a').on('shown.bs.tab', function (e) {
        for (var i = 0; i < arr.length; i++) {
            arr[i].resize();
            
        }

    });
  

});
