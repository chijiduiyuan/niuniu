var ui = {
    //饼图
    pie:function(obj){
        var Chart = echarts.init(document.getElementById(obj.id));
        var option = {
            title : {
                text: obj.title,
                subtext: obj.SumpayNum,
                subtextStyle:{
                    color:'#e00',
                    fontWeight:'800'
                },
                x:'center'
            },
            tooltip : {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient : 'vertical',
                x:'0',
                y:'30',
                data:obj.platformList
            },
            calculable : true,
            series : [
                {
                    name:obj.title,
                    type:'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    avoidLabelOverlap: false, 
                    data:obj.value
                }
            ]
        };
        Chart.setOption(option,true);
        return Chart;
    },

    //柱形图
    bar:function(obj){
        var barChart = echarts.init(document.getElementById(obj.id));
        var baroption = {
            title : {
                text: obj.title
            },
            tooltip : {
                trigger: 'axis'
            },
            legend: {
                data:obj.subTitle
            },
            calculable : true,

            xAxis : [
                {
                    type : 'category',
                    data : obj.x
                }
            ],
            yAxis : [
                {
                    type : 'value'
                }
            ],
            series : [
                {
                    name:obj.name1,
                    type:'bar',
                    data:obj.data1,
                    markPoint : {
                        data : ['']
                    },
                    markLine : {
                        data : [
                            {type : 'average', name: '平均值'}
                        ]
                    }
                },
                {
                    name:obj.name2,
                    type:'bar',
                    data:obj.data2,
                    markPoint : {
                        data : ['']
                    },
                    markLine : {
                        data : [
                            {type : 'average', name : '平均值'}
                        ]
                    }
                }
            ]
        };
        barChart.setOption(baroption,true);
        return barChart;
    },
    //折线
    line:function(obj){
        var lineChartk = echarts.init(document.getElementById(obj.id));
        var lineoptionk = {
            title : {
                text: obj.title
            },
            tooltip : {
                trigger: 'axis'
            },
            legend: {
                data:['']
            },
            calculable : true,
            xAxis : [
                {
                    type : 'category',
                    boundaryGap : false,
                    data : obj.x
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    axisLabel : {
                        // formatter: '{value} °C'
                    }
                }
            ],
            series : [
                {
                    name:obj.name,
                    type:'line',
                    data:obj.data,
                    markPoint : {
                        data : [
                            {type : 'max', name: '最大值'},
                            {type : 'min', name: '最小值'}
                        ]
                    },
                    markLine : {
                        data : [
                            {type : 'average', name: '平均值'}
                        ]
                    }
                }
            ]
        };
        lineChartk.setOption(lineoptionk,true);
        return lineChartk;
    }
}