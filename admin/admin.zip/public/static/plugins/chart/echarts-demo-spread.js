$(function () {


   
    // 用户数量
    var barChart = echarts.init(document.getElementById("echarts-bar-user"));
    var baroption = {
        title : {
            text: '新老用户'
        },
        tooltip : {
            trigger: 'axis'
        },
        legend: {
            data:['新用户','老用户']
        },
        calculable : true,

        xAxis : [
            {
                type : 'category',
                data : ['10/9','10/10','10/11','10/12','10/13','10/14','10/15']
            }
        ],
        yAxis : [
            {
                type : 'value'
            }
        ],
        series : [
            {
                name:'新用户',
                type:'bar',
                data:[11, 110, 150, 13, 12, 20, 10],
                markPoint : {
                    data : ['']
                },
                markLine : {
                    data : [
                        {type : 'average', name: '平均值'}
                    ]
                }
            },
            {
                name:'老用户',
                type:'bar',
                data:[1, 2, 2, 50, 3, 2, 0],
                markPoint : {
                    data : ['']
                },
                markLine : {
                    data : [
                        {type : 'average', name : '平均值'}
                    ]
                }
            }
        ]
    };
    barChart.setOption(baroption,true);
    console.log(baroption)


    // 房间数量
    var lineChart = echarts.init(document.getElementById("echarts-line-room"));
    var lineoption = {
        title : {
            text: '房间消耗'
        },
        tooltip : {
            trigger: 'axis'
        },
        legend: {
            data:['']
        },
        calculable : true,
        xAxis : [
            {
                type : 'category',
                boundaryGap : false,
                data : ['周一','周二','周三','周四','周五','周六','周日']
            }
        ],
        yAxis : [
            {
                type : 'value',
                axisLabel : {
                    // formatter: '{value} °C'
                }
            }
        ],
        series : [
            {
                name:'开房最高',
                type:'line',
                data:[11, 11, 15, 13, 12, 13, 10],
                markPoint : {
                    data : [
                        {type : 'max', name: '最大值'},
                        {type : 'min', name: '最小值'}
                    ]
                },
                markLine : {
                    data : [
                        {type : 'average', name: '平均值'}
                    ]
                }
            }
        ]
    };
    lineChart.setOption(lineoption,true);

    // 房卡消耗
    var lineChartk = echarts.init(document.getElementById("echarts-line-card"));
    var lineoptionk = {
        title : {
            text: '房卡消耗'
        },
        tooltip : {
            trigger: 'axis'
        },
        legend: {
            data:['']
        },
        calculable : true,
        xAxis : [
            {
                type : 'category',
                boundaryGap : false,
                data : ['周一','周二','周三','周四','周五','周六','周日']
            }
        ],
        yAxis : [
            {
                type : 'value',
                axisLabel : {
                    // formatter: '{value} °C'
                }
            }
        ],
        series : [
            {
                name:'房卡消耗最高',
                type:'line',
                data:[11, 11, 15, 13, 12, 13, 10],
                markPoint : {
                    data : [
                        {type : 'max', name: '最大值'},
                        {type : 'min', name: '最小值'}
                    ]
                },
                markLine : {
                    data : [
                        {type : 'average', name: '平均值'}
                    ]
                }
            }
        ]
    };
    lineChartk.setOption(lineoptionk,true);

    // 房卡充值
    var lineChartl = echarts.init(document.getElementById("echarts-line-pay"));
    var lineoptionl = {
        title : {
            text: '房卡充值'
        },
        tooltip : {
            trigger: 'axis'
        },
        legend: {
            data:['']
        },
        calculable : true,
        xAxis : [
            {
                type : 'category',
                boundaryGap : false,
                data : ['周一','周二','周三','周四','周五','周六','周日']
            }
        ],
        yAxis : [
            {
                type : 'value',
                axisLabel : {
                    // formatter: '{value} °C'
                }
            }
        ],
        series : [
            {
                name:'房卡充值最高',
                type:'line',
                data:[11, 11, 15, 13, 12, 150, 10],
                markPoint : {
                    data : [
                        {type : 'max', name: '最大值'},
                        {type : 'min', name: '最小值'}
                    ]
                },
                markLine : {
                    data : [
                        {type : 'average', name: '平均值'}
                    ]
                }
            }
        ]
    };
    lineChartl.setOption(lineoptionl,true);



});
