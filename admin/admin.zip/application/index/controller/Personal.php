<?php
/**
 * 个人中心模块
 */
namespace app\index\controller;
use app\index\controller\Base;

class Personal extends Base
{
    //个人中心
    public function index()
    {
        //玩家信息
        $data['user'] = $this->db->table('user')->where(array('uid'=>session('uid')))->item();
        //dump($data);
        $this->assign('data',$data);
        return $this->fetch();
    }

    //退出登陆
    public function logout(){
        session('uid',null);
		exit(json_encode(array('code'=>1,'msg'=>'退出成功')));
    }

}
