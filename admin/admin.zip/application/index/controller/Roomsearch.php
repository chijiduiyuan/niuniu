<?php
/**
 * 开房查询模块
 */
namespace app\index\controller;
use app\index\controller\Base;

class Roomsearch extends Base
{
    //房间列表
    public function index(){
        $id = max(0,input('get.id'));
        $data['gameList'] = $this->db->table('gamelist')->lists();
        if($id > 0){
            $data['rooms'] = $this->db->table('rooms')->where(array('create_uid'=>session('uid'),'game_id'=>$id))->lists();
        }else{
            $data['rooms'] = $this->db->table('rooms')->where(array('create_uid'=>session('uid')))->lists();
        }
        $this->assign('data',$data);
        return $this->fetch();
    }

    //房间详情
    public function info(){
        $id = (int)input('get.id');
        
    }
}